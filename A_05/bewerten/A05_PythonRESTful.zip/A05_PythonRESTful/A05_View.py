# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'View.ui'
#
# Created: Fri Oct 20 00:50:43 2017
#      by: pyside-uic 0.2.15 running on PySide 1.2.4
#
# WARNING! All changes made in this file will be lost!

from PySide import QtCore, QtGui

class Ui_A05_GUI(object):
    def setupUi(self, A05_GUI):
        A05_GUI.setObjectName("A05_GUI")
        A05_GUI.resize(703, 634)
        A05_GUI.setAutoFillBackground(False)
        self.centralwidget = QtGui.QWidget(A05_GUI)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayout = QtGui.QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName("gridLayout")
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.title_label = QtGui.QLabel(self.centralwidget)
        self.title_label.setObjectName("title_label")
        self.horizontalLayout_2.addWidget(self.title_label)
        self.selection = QtGui.QComboBox(self.centralwidget)
        self.selection.setObjectName("selection")
        self.selection.addItem("")
        self.selection.addItem("")
        self.horizontalLayout_2.addWidget(self.selection)
        self.gridLayout.addLayout(self.horizontalLayout_2, 0, 0, 1, 1)
        self.gridLayout_2 = QtGui.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.start = QtGui.QLabel(self.centralwidget)
        self.start.setObjectName("start")
        self.gridLayout_2.addWidget(self.start, 0, 0, 1, 1)
        self.destination = QtGui.QLabel(self.centralwidget)
        self.destination.setObjectName("destination")
        self.gridLayout_2.addWidget(self.destination, 1, 0, 1, 1)
        self.input_origin = QtGui.QLineEdit(self.centralwidget)
        self.input_origin.setObjectName("input_origin")
        self.gridLayout_2.addWidget(self.input_origin, 0, 1, 1, 1)
        self.input_destination = QtGui.QLineEdit(self.centralwidget)
        self.input_destination.setObjectName("input_destination")
        self.gridLayout_2.addWidget(self.input_destination, 1, 1, 1, 1)
        self.gridLayout.addLayout(self.gridLayout_2, 1, 0, 1, 1)
        self.output_display = QtGui.QTextEdit(self.centralwidget)
        self.output_display.setEnabled(True)
        self.output_display.setReadOnly(True)
        self.output_display.setObjectName("output_display")
        self.gridLayout.addWidget(self.output_display, 2, 0, 1, 1)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.submit = QtGui.QPushButton(self.centralwidget)
        self.submit.setObjectName("submit")
        self.horizontalLayout.addWidget(self.submit)
        self.reset = QtGui.QPushButton(self.centralwidget)
        self.reset.setObjectName("reset")
        self.horizontalLayout.addWidget(self.reset)
        self.close = QtGui.QPushButton(self.centralwidget)
        self.close.setObjectName("close")
        self.horizontalLayout.addWidget(self.close)
        self.gridLayout.addLayout(self.horizontalLayout, 3, 0, 1, 1)
        self.status = QtGui.QLabel(self.centralwidget)
        self.status.setObjectName("status")
        self.gridLayout.addWidget(self.status, 4, 0, 1, 1)
        A05_GUI.setCentralWidget(self.centralwidget)

        self.retranslateUi(A05_GUI)
        QtCore.QObject.connect(self.close, QtCore.SIGNAL("clicked()"), A05_GUI.close)
        QtCore.QObject.connect(self.reset, QtCore.SIGNAL("clicked()"), self.output_display.clear)
        QtCore.QObject.connect(self.reset, QtCore.SIGNAL("clicked()"), self.input_destination.clear)
        QtCore.QObject.connect(self.reset, QtCore.SIGNAL("clicked()"), self.input_origin.clear)
        QtCore.QMetaObject.connectSlotsByName(A05_GUI)

    def retranslateUi(self, A05_GUI):
        A05_GUI.setWindowTitle(QtGui.QApplication.translate("A05_GUI", "Python RESTful Service", None, QtGui.QApplication.UnicodeUTF8))
        self.title_label.setText(QtGui.QApplication.translate("A05_GUI", "Google Navigator", None, QtGui.QApplication.UnicodeUTF8))
        self.selection.setItemText(0, QtGui.QApplication.translate("A05_GUI", "JSON", None, QtGui.QApplication.UnicodeUTF8))
        self.selection.setItemText(1, QtGui.QApplication.translate("A05_GUI", "XML", None, QtGui.QApplication.UnicodeUTF8))
        self.start.setText(QtGui.QApplication.translate("A05_GUI", "Start:", None, QtGui.QApplication.UnicodeUTF8))
        self.destination.setText(QtGui.QApplication.translate("A05_GUI", "Ziel:", None, QtGui.QApplication.UnicodeUTF8))
        self.submit.setText(QtGui.QApplication.translate("A05_GUI", "Submit", None, QtGui.QApplication.UnicodeUTF8))
        self.reset.setText(QtGui.QApplication.translate("A05_GUI", "Reset", None, QtGui.QApplication.UnicodeUTF8))
        self.close.setText(QtGui.QApplication.translate("A05_GUI", "Close", None, QtGui.QApplication.UnicodeUTF8))
        self.status.setText(QtGui.QApplication.translate("A05_GUI", "Berechnung nicht ausgeführt", None, QtGui.QApplication.UnicodeUTF8))

