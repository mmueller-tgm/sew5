.. Python Rest Applikation A05 documentation master file, created by
   sphinx-quickstart on Wed Oct 18 10:07:40 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Python Rest Applikation A05's documentation!
=======================================================

Contents:

.. toctree::
   :maxdepth: 2



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

