A05_View Module
===============

:mod:`A05_View` Module
----------------------

.. automodule:: A05_View
    :members:
    :undoc-members:
    :special-members: __init__
    :show-inheritance:
