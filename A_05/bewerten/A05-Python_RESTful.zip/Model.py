import requests

class Model():
    """
    @author Zuba Lukas
    @version 2017-10-13
    In dieser Klasse wird das eigntliche Window erstellt
    :ivar String ziel:   ziel, wohin die Reise geht
    :ivar String start:  start, von wo aus die Reise gestartet wird
    :ivar String status: status, hält Informationen über den aktuellen Programmstand
    :ivar String weg:    weg, in dem drinnen steht, wie man vom Start zum Ziel kommt
    :ivar String url:    url, über welche Api die Anfrage gehen soll
    """
    def __init__(self):
        """
        Instanziert alle Instanzvariablen
        """
        self.ziel = ""
        self.start = ""
        self.status = ""
        self.weg = ""
        self.url = "http://maps.googleapis.com/maps/api/directions/json"


    def getGoogleAnswer(self):
        """
        Setzt die Parameter über die Anfrage an Google,
        fragt Google dann ab und liefert die Response zurück

        :return: Response rweg: Response von Google als JSON Objekt
        """
        params = {"origin": self.start,
                  "destination": self.ziel,
                  "sensor": "false",
                  "language": "de"
                  }
        return requests.get(self.url, params)