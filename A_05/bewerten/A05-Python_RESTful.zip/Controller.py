import view
import Model
from PySide import QtGui

class Controller(QtGui.QMainWindow):
    """
    @author Zuba Lukas
    @version 2017-10-13

    In dieser Klasse werden View und Model instanziert, die Buttons in der View mit Methoden verknüpft und die SubmitButton Logik durchgeführt.

    :ivar Model model:     model, das alle daten hält
    :ivar view view: view, über die wird alles angenommen und ausgegeben
    :ivar String weg:      weg, in dem die wegbeschreibung steht
    """
    def __init__(self,parent = None):
        """
        Ruft den Superkonstruktor auf, erstellt das Model, erstellt die View ,startet die GUI und verbindet die Buttons
        """
        super().__init__(parent)
        self.model = Model.Model()
        self.view = view.Ui_MainWindow()
        self.view.setupUi(self)

        self.connectButtons()
        self.resetUI()
        self.show()



    def connectButtons(self):
        """
        Verbindet die Buttons mit einer Methode

        :return: void
        """
        self.view.submitButton_3.clicked.connect(self.askGoogle)
        self.view.resetButton_2.clicked.connect(self.resetUI)


    def askGoogle(self):
        """
        Speichert die Eingabewerte, sendet eine Anfrage an Google Maps Api,
        speichert die Response, verarbeitet diese Response und gibt den erstellten Weg in der GUI aus

        :return: void
        """
        self.model.start = self.view.lineEdit.text()
        self.model.ziel = self.view.lineEdit_2.text()
        self.view.statusbar.showMessage("Google wird befragt ...")
        response = self.model.getGoogleAnswer().json()



        #Geht durch das JSON und nimmt die Infos aus allen legs und allen Steps mit
        for route in response['routes']:
            for leg in route['legs']:
                self.model.weg += 'Die <b>Gesamtdistanz</b> beträgt <b>' + leg['distance']['text'] + '</b> '
                self.model.weg += 'Die <b>Gesamtdauer</b> beträgt <b>' + leg['duration']['text'] + '</b><br>'

                for step in leg['steps']:
                    self.model.weg += (step['html_instructions'])
                    self.model.weg += ', Entfernung: ' + step['distance']['text'] + ', Dauer: ' + step['duration'][
                        'text'] + '<br>'

        self.updateUI(self.model.weg)
        self.view.statusbar.showMessage("Berechnung durchgeführt")

    def resetUI(self):
        """
        Setzt alle Textfelder in der GUI zurück

        :return: void
        """
        self.view.lineEdit.setText("")
        self.view.lineEdit_2.setText("")
        self.view.textBrowser.setText("")
        self.view.statusbar.showMessage("OK")

    def updateUI(self,data):
        """
        Setzt den Weg im Textbrowser und interpretiert die HTML Tags

        :param data: String, in dem der Weg steht
        :return: void
        """
        self.view.textBrowser.setText(data)
        self.view.textBrowser.toHtml()
