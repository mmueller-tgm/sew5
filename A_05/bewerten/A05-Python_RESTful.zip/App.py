import Controller
import sys
from PySide.QtGui import *

class App(QApplication):
    """
   @author Zuba Lukas
   @version 2017-10-13
   Diese Klasse initialisiert den QApplication Klasse
   und erstellt eine Instanz von Controller
   :ivar Controller controller:      controller, welcher alle anderen klassen erstellt und startet
   """
    def __init__(self,sys_argv):
        """
       Initialisiert die Basis Klasse QApplication, übernimmt die Parameter und erstellt einen Controller

       :param sys_argv: sys_argv, wird gebraucht um den Basiskonstruktur zu starten
       """
        super(App, self).__init__(sys_argv)
        self.controller = Controller.Controller()

"""
Erstellt eine eigene App
und startet diese App
"""
if __name__ == '__main__':
    app = App(sys.argv)
    sys.exit(app.exec_())