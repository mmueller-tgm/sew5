import base64
from Abstract import SocketDecorator
from Crypto.Cipher import AES


class ConcreteBASE64Decorator(SocketDecorator):
    def __init__(self, component):
        SocketDecorator.__init__(self, component)

    def encode(self, msg):
        msg = base64.standard_b64encode(msg.encode('utf-8')).decode("utf-8")
        msg = self.component.encode(msg)
        return msg

    def decode(self, msg):
        msg = self.component.decode(msg)
        msg = base64.standard_b64decode(msg.encode('utf-8')).decode("utf-8")
        return msg


class ConcreteBASE16Decorator(SocketDecorator):
    def __init__(self, component):
        SocketDecorator.__init__(self, component)

    def encode(self, msg):
        msg = base64.b16encode(msg.encode('utf-8')).decode("utf-8")
        msg = self.component.encode(msg)
        return msg

    def decode(self, msg):
        msg = self.component.decode(msg)
        msg = base64.b16decode(msg.encode('utf-8')).decode("utf-8")
        return msg


class ConcreteBASE32Decorator(SocketDecorator):
    def __init__(self, component):
        SocketDecorator.__init__(self, component)

    def encode(self, msg):
        msg = base64.b32encode(msg.encode('utf-8')).decode("utf-8")
        msg = self.component.encode(msg)
        return msg

    def decode(self, msg):
        msg = self.component.decode(msg)
        msg = base64.b32decode(msg.encode('utf-8')).decode("utf-8")
        return msg


class ConcreteOutputDecorator(SocketDecorator):
    def __init__(self, component):
        SocketDecorator.__init__(self, component)

    def encode(self, msg):
        print(msg)
        return self.component.encode(msg)

    def decode(self, msg):
        print(msg)
        return self.component.decode(msg)

"""
class ConcreteAESDecorator(SocketDecorator):
    def __init__(self, component, key):
        SocketDecorator.__init__(self, component)
        self.AES = AES.new(key, AES.MODE_CBC, 'This is an IV456')

    def encode(self, msg):
        msg = self.AES.encrypt(msg.encode('utf-8')).decode('utf-8')
        msg = self.component.encode(msg)
        return msg

    def decode(self, msg):
        msg = self.component.decode(msg)
        msg = self.AES.decrypt(msg.encode('utf-8')).decode('utf-8')
        return msg
"""
