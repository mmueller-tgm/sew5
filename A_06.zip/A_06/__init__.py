from Abstract import Socket
from Decorators import *
from Sockets import TestSocket


if __name__ == "__main__":
    s1 = ConcreteBASE64Decorator(ConcreteBASE16Decorator(TestSocket()))
    a = s1.encode("eyy")
    print(a)
    b = s1.decode(a)
    print(b)
f