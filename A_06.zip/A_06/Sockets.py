from Abstract import Socket


class TestSocket(Socket):
    def __init__(self):
        Socket.__init__(self)

    def encode(self, msg):
        return msg

    def decode(self, msg):
        return msg
