from abc import ABC, abstractmethod


class Socket(ABC):
    @abstractmethod
    def encode(self, msg):
        pass

    @abstractmethod
    def decode(self, msg):
        pass


class SocketDecorator(Socket, ABC):
    def __init__(self, component):
        Socket.__init__(self)
        self.component = component

    def encode(self, msg):
        msg = msg
        return self.component.encode(msg)

    def decode(self, msg):
        msg = self.component.decode(msg)
        return msg
